"""Pydantic request/response schemas."""
