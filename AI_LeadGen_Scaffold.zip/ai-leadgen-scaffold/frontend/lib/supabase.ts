/**
 * Supabase client factories for browser and server contexts.
 *
 * - `createClient()`      -> use inside Client Components ("use client").
 * - `createServerClient()` -> use inside Server Components / Route Handlers /
 *                             Server Actions where the Next.js `cookies()`
 *                             API is available.
 */

import { createBrowserClient, createServerClient as createSSRClient } from "@supabase/ssr";
import { cookies } from "next/headers";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL as string;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY as string;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  // eslint-disable-next-line no-console
  console.warn(
    "Supabase environment variables are not fully configured. " +
      "Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY."
  );
}

/**
 * Browser-side Supabase client. Safe to use in Client Components.
 */
export function createClient() {
  return createBrowserClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}

/**
 * Server-side Supabase client bound to the current request's cookies.
 * Use inside Server Components, Route Handlers, and Server Actions.
 */
export function createServerClient() {
  const cookieStore = cookies();

  return createSSRClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value;
      },
      set(name: string, value: string, options: Record<string, unknown>) {
        try {
          cookieStore.set({ name, value, ...options });
        } catch {
          // The `set` method is called from a Server Component context in
          // some Next.js versions, where mutating cookies is not allowed.
          // This can be safely ignored if middleware refreshes the session.
        }
      },
      remove(name: string, options: Record<string, unknown>) {
        try {
          cookieStore.set({ name, value: "", ...options });
        } catch {
          // See note above.
        }
      },
    },
  });
}
